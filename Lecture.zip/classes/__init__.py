from classes.student import Student
from classes.course import Course
from classes.teacher import Teacher