create_account():
#     first_name = view.get_f_name()
#     last_name = view.get_l_name()
#     pin = view.get_pin()
#     confirm_pin = view.pin_confirm(pin)
#     if confirm_pin != pin:
#         print("wrong pin")
#         create_account()
#     else:
#         account_number = "N4321" + str(random.randint(100, 1000))

#         model.new_account(account_number, first_name, last_name, confirm_pin)
#         model.save()
#         view.new_account(account_number)
#         view.welcome_menu()
#         main_menu()
